#include "DragonBallz.hpp"
#include<iostream>
//void DragonBallz::drawObjects(){  
//}

//void DragonBallz::createObject(int x, int y){
  //  std::cout<<"Mouse clicked at: "<<x<<" -- "<<y<<std::endl;
//}

DragonBallz::DragonBallz(SDL_Renderer *renderer, SDL_Texture *asst):gRenderer(renderer), assets(asst){}
